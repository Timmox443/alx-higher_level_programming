-- Displays the number of records
-- Query to display the number of records with id = 89 in a table
SELECT COUNT(*) as id FROM first_table WHERE id=89;

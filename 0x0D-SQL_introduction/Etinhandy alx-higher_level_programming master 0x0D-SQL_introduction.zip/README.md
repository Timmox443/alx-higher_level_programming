# 0x0D. SQL - Introduction
This project is about basic use of DBMS, DDL and DML project on MySQL (A Relational Datatabase Managment System).

-- Inserts a new row in a table
-- Query to insert a new row in the table first_table
INSERT INTO first_table (id, name) VALUES (89, "Best School");

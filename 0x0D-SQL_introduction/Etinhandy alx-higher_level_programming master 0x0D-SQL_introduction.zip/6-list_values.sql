-- Lists all rows of a table
-- Lists all rows of the table first_table from the database hbtn_0c_0
SELECT * FROM first_table;

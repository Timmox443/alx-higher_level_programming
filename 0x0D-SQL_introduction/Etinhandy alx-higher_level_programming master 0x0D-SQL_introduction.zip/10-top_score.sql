-- Script that lists all records in a table
-- Query to lists all records in the table second_table of a database
SELECT score, name FROM second_table ORDER BY score DESC;

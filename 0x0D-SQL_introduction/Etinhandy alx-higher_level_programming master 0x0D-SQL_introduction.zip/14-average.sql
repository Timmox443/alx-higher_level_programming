-- Script that computes the score average of all records in a table
-- Query to computes the score average of all records in the table second_table
SELECT AVG(score) AS average FROM second_table;
